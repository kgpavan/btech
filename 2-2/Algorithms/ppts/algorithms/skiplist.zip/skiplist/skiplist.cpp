/*
 * A sample implementation of a dynamic set class based on 
 * doubly-linked list.  You may wish to build your skip-list
 * implementation on this code, or you may wish to start from
 * scratch.  Whatever you do, you should strive for simple, 
 * readable code and avoid high-level C++ constructs such as 
 * templates.
 */

#include <stddef.h>
#include <float.h>
#include <assert.h>
#include "skiplist.h"

sl_set::sl_set(float prob)
{
	head.next = &tail;
	tail.prev = &head;
	p = prob;
	
	// verify that probability is valid:
	assert(prob > 0.0 && prob < 1.0);

	// Should never access these:
	head.prev = tail.next = NULL;

	// head and tail keys serve as sentinels:
	head.key = -FLT_MAX;
	tail.key = FLT_MAX;
}

/* 
 * Return a pointer to an element with the given key, or NULL 
 * if no such element
 */
sl_element *sl_set::search(float key) const
{
	sl_element *tmp = head.next;

	while (key > tmp->key)
	{
		tmp = tmp->next;
	}
	if (key == tmp->key)
	{
		return tmp;
	}
	else
	{
		return NULL;
	}
}

/* 
 * Creates a new element with the specified key and satellite data, and inserts
 * it into the list in sorted order.  The head and tail elements serve as 
 * dummy elements with sentinel values, so that the insert implementation doesn't
 * have to bother checking for NULL pointers, etc.
 */
sl_element *sl_set::insert(void *data, float key)
{
	sl_element *new_el = new sl_element;
	sl_element *tmp = head.next;

	new_el->data = data;
	new_el->key = key;
	
	while (key > tmp->key)
	{
		tmp = tmp->next;
	}
	// new_el should now be inserted in front of element pointed to by tmp
	new_el->next = tmp;
	new_el->prev = tmp->prev;
	new_el->next->prev = new_el;
	new_el->prev->next = new_el;

	return new_el;
}

/* 
 * Remove the specified element.  Should never be called on the head or tail
 * elements.  It is the caller's responsibility to ensure that the specified 
 * element exists and can be deleted, and that any memory pointed to by 
 * el->data is freed first if necessary.
 */
void sl_set::remove(sl_element *el)
{
	el->next->prev = el->prev;
	el->prev->next = el->next;
	delete el;
}

/*
 * Returns the value of the first element in the list (disregarding dummy 
 * element "head", or NULL if the list contains no elements.
 */
sl_element *sl_set::min() const
{
	if (head.next == &tail)
	{
		return NULL;
	}
	else
	{
		return head.next;
	}
}

sl_element *sl_set::max() const
{
	if (tail.prev == &head)
	{
		return NULL;
	}
	else
	{
		return tail.prev;
	}
}

/* 
 * Returns the element with the next largest key, or NULL if this is the 
 * largest element in the set.
 */
sl_element *sl_set::succ(sl_element *el) const 
{
	if (el->next == &tail)
	{
		return NULL;
	}
	else
	{
		return el->next;
	}
}

/* 
 * Returns the element with the next smallest key, or NULL if this is the 
 * smallest element in the set.
 */
sl_element *sl_set::pred(sl_element *el) const 
{
	if (el->prev == &head)
	{
		return NULL;
	}
	else
	{
		return el->prev;
	}
}


