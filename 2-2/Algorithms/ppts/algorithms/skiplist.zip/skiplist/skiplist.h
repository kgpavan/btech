/*
 * Header file for a dynamic set based on skip lists.
 * 
 * Your implementation should support all the public methods below.
 * You should use only very simple, straightforward C++ primitives:
 * no templates, etc.  No code reuse from previous classes, or from
 * provided libraries (e.g., STL).  The idea is to code everything
 * from scratch in the simplest manner possible.
 */

typedef struct _sl_element
{
	void *data;
	float key;
	struct _sl_element *next;
	struct _sl_element *prev;
} sl_element;

class sl_set
{
private:
	/* 
	 * You design the underlying data structure and any private methods;
	 * the below are part of the sample linked list implementation and 
	 * you may wish to replace them
	 */
	sl_element head, tail;  // head and tail are dummy elements
	float p;

public:
	// Constructor takes the probability of adding element to next list
	sl_set(float prob=0.5); 

	// return the minimum and maximum elements in a set:
	sl_element * min() const;		
	sl_element * max() const;		

	// return the next and previous elements in the sorted order:
	sl_element * succ(sl_element *el) const;
	sl_element * pred(sl_element *el) const;

	// Return pointer to an element with a given key, or NULL if none exists:
	sl_element * search(float key) const;

	// Insert an element with the given key and data, return ptr to element:
	sl_element * insert(void *data, float key);

	// Delete the given element:
	void remove(sl_element *el);
};