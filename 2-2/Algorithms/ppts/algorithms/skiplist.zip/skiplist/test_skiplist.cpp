#include "skiplist.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void main()
{
	printf("Testing skiplist...\n");
	printf("Initializing...\n");
	
	sl_set list(0.25);
		
	printf("Searching for a key in an empty set...\n");
	sl_element *tmp = list.search(1.0);

	if (tmp == NULL) 
		printf("    Good: Returned NULL\n");
	else
		printf("    Uh-oh: Returned pointer 0x%x\n", tmp);

	/* 
	 * Seed the random-number generator with current time so that
     * the numbers will be different every time we run.
     */
	srand((unsigned)time(NULL));

	for (int i=0; i<100; i++)
		list.insert(NULL, (float) rand()/ (float) RAND_MAX);
	for (i=0; i<100; i++)
	{
		sl_element *max_el = list.max();

		printf("%.4f \n", max_el->key);
		list.remove(max_el);
	}
	// list should now be empty
	printf("Searching for a key in an empty set...\n");
	tmp = list.search(0.0);
	if (tmp == NULL) 
		printf("    Good: Returned NULL\n");
	else
		printf("    Uh-oh: Returned 0x%x\n", tmp);
}